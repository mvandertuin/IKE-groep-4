-- phpMyAdmin SQL Dump
-- version 3.4.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 29, 2011 at 03:53 PM
-- Server version: 5.1.51
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ike`
--

-- --------------------------------------------------------

--
-- Table structure for table `ike_session`
--

CREATE TABLE IF NOT EXISTS `ike_session` (
  `iuID` int(11) NOT NULL,
  `sessID` varchar(64) NOT NULL,
  `valid` int(11) NOT NULL,
  `storage` text NOT NULL,
  UNIQUE KEY `sessID` (`sessID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ike_users`
--

CREATE TABLE IF NOT EXISTS `ike_users` (
  `uID` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `wachtwoord` char(32) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `validated` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ike_users`
--

INSERT INTO `ike_users` (`uID`, `naam`, `email`, `wachtwoord`, `type`, `validated`) VALUES
(1, 'Ruben', 'ruben@dcm360.nl', '33aa2e21b070edfd37cf5659f3583886', 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
