<?php
/*
 *	Global configuration file
 */

//Set maintenance page
$maintenance = false;

/*
 *	The relative path of the framework relative to the document root (starting with a slash)
 */
$frameworkRoot = '/ike/';

/*
 *	Database configutaion
 */
$db_host = 'localhost';
$db_name = 'ike';
$db_user = 'ike';
$db_pass = 'ike-pwd';
$db_tableprefix = 'ike_';

/*
 *	Email configuration
 */
$canMail = false;

/*
 * Scripts
 */
$scripts = array();
?>