<?php
global $genres;
$genres = array("alternative" => "Alternatief",
    "blues" => "Blues",
    "country" => "Country",
    "dance" => "Dance",
    "electronic" => "Electronic",
    "hiphop" => "Hip-hop",
    "jazz" => "Jazz",
    "children" => "Kindermuziek",
    "classic" => "Klassiek",
    "metal" => "Metal",
    "pop" => "Pop",
    "rap" => "Rap",
    "reggae" => "Reggae",
    "rock" => "Rock",
    "world" => "Wereldmuziek");
?>